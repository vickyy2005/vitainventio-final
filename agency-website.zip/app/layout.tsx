import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Inter, Space_Grotesk } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' })
const spaceGrotesk = Space_Grotesk({ subsets: ['latin'], variable: '--font-space' })

export const metadata: Metadata = {
  title: 'Kinetic — Digital experiences that move business forward',
  description: 'Kinetic is a premium web development and AI automation agency for ambitious teams.',
  generator: 'v0.app',
  metadataBase: new URL('https://kinetic.studio'),
  openGraph: {
    title: 'Kinetic — Digital experiences that move business forward',
    description: 'Premium websites, AI automation systems, and digital products for ambitious teams.',
    type: 'website',
    siteName: 'Kinetic Studio',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Kinetic — Digital experiences that move business forward',
    description: 'Premium websites, AI automation systems, and digital products for ambitious teams.',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#0d0d0d',
  userScalable: true,
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const organizationSchema = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Kinetic Studio',
    url: 'https://kinetic.studio',
    description: 'Premium web development and AI automation agency.',
    email: 'hello@kinetic.studio',
  }

  return (
    <html lang="en" className="bg-[#0d0d0d]">
      <body className={`${inter.variable} ${spaceGrotesk.variable} antialiased`}>
        {children}
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }} />
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
