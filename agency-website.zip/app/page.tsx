'use client'

import { FormEvent, useEffect, useRef, useState } from 'react'
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Bot,
  Check,
  ChevronDown,
  Code2,
  Database,
  Globe2,
  Layers3,
  Link,
  Menu,
  MessageCircle,
  MonitorSmartphone,
  MousePointer2,
  PenTool,
  Play,
  Rocket,
  Send,
  ShieldCheck,
  Sparkles,
  Star,
  X,
  Zap,
} from 'lucide-react'

const navItems = [
  ['Home', 'home'], ['About', 'about'], ['Services', 'services'], ['Portfolio', 'portfolio'],
  ['Process', 'process'], ['Pricing', 'pricing'], ['Testimonials', 'testimonials'], ['Blogs', 'blog'], ['Contact', 'contact'],
]

const services = [
  { icon: Globe2, title: 'Website Development', text: 'High-performance marketing sites that turn attention into action.' },
  { icon: MonitorSmartphone, title: 'eCommerce', text: 'Conversion-led storefronts engineered for memorable shopping journeys.' },
  { icon: PenTool, title: 'Landing Pages', text: 'Focused launch pages with crisp messaging and measurable outcomes.' },
  { icon: Layers3, title: 'UI / UX Design', text: 'Clear, expressive product experiences users understand instantly.' },
  { icon: Code2, title: 'Custom Software', text: 'Purpose-built platforms that remove friction from complex workflows.' },
  { icon: Bot, title: 'AI Automation', text: 'Practical AI systems that give your team leverage, not more tools.' },
  { icon: Database, title: 'CRM Development', text: 'Connected customer systems that keep your pipeline moving.' },
  { icon: Rocket, title: 'SaaS Applications', text: 'Scalable foundations for ambitious products and recurring revenue.' },
]

const projects = [
  { category: 'SaaS Platform', title: 'Northstar Finance', text: 'A confident fintech experience built to make complex decisions feel simple.', image: 'https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=1200&q=85' },
  { category: 'eCommerce', title: 'Aster Objects', text: 'A refined digital flagship for a modern objects and interiors brand.', image: 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=1200&q=85' },
  { category: 'AI Automation', title: 'Relay Ops', text: 'An intelligent operations command center that gives teams back their day.', image: 'https://images.unsplash.com/photo-1551434678-e076c223a692?auto=format&fit=crop&w=1200&q=85' },
]

const testimonials = [
  { quote: 'They made our complicated product feel inevitable. The new site has become our best salesperson.', name: 'Maya Chen', role: 'Co-founder, Northstar', initials: 'MC' },
  { quote: 'A rare partner who brings taste, speed, and strategic thinking to every conversation.', name: 'Jon Bell', role: 'CEO, Relay Ops', initials: 'JB' },
  { quote: 'Our conversion rate moved before the launch campaign even started. The clarity was the unlock.', name: 'Ari Stone', role: 'Marketing Lead, Aster', initials: 'AS' },
]

const faqs = [
  ['What kind of projects do you take on?', 'We partner with ambitious teams on high-impact websites, digital products, eCommerce experiences, and practical AI automation systems.'],
  ['How do you work with in-house teams?', 'We can lead the entire engagement or plug into your existing team as a focused design and development partner.'],
  ['How long does a typical project take?', 'Most focused launches take 4–8 weeks. Larger platforms are planned in clear milestones so value ships early and often.'],
  ['Do you offer ongoing support?', 'Yes. Our care plans cover iteration, performance, experiments, and the small improvements that compound after launch.'],
]

const techStack = ['Next.js', 'React', 'TypeScript', 'Tailwind', 'OpenAI', 'Supabase', 'Node.js', 'Vercel', 'AWS', 'Docker']

function Reveal({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const node = ref.current
    if (!node) return
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) { node.classList.add('is-visible'); observer.disconnect() }
    }, { threshold: 0.12 })
    observer.observe(node)
    return () => observer.disconnect()
  }, [])
  return <div ref={ref} className={`reveal ${className}`}>{children}</div>
}

function SectionHeading({ eyebrow, title, copy, light = false }: { eyebrow: string; title: string; copy?: string; light?: boolean }) {
  return <div className={`section-heading ${light ? 'section-heading-light' : ''}`}>
    <p className="eyebrow"><span />{eyebrow}</p>
    <h2>{title}</h2>
    {copy && <p className="section-copy">{copy}</p>}
  </div>
}

function ButtonLink({ children, href, secondary = false }: { children: React.ReactNode; href: string; secondary?: boolean }) {
  return <a href={href} className={`button-link ${secondary ? 'button-link-secondary' : ''}`}>{children}<ArrowRight aria-hidden="true" /></a>
}

export default function Page() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [activeFaq, setActiveFaq] = useState(0)
  const [submitted, setSubmitted] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setSubmitted(true)
  }

  return (
    <main id="home" className="site-shell">
      <header className={`site-nav ${scrolled ? 'site-nav-scrolled' : ''}`}>
        <a href="#home" className="brand" aria-label="Kinetic home"><span className="brand-mark">K</span><span>KINETIC<span className="brand-dot">.</span></span></a>
        <nav className="desktop-nav" aria-label="Main navigation">{navItems.map(([label, id]) => <a key={id} href={`#${id}`}>{label}</a>)}</nav>
        <a href="#contact" className="nav-cta">Book a Free Call <ArrowUpRightIcon /></a>
        <button className="menu-button" aria-label={menuOpen ? 'Close menu' : 'Open menu'} onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</button>
        {menuOpen && <nav className="mobile-nav" aria-label="Mobile navigation">{navItems.map(([label, id]) => <a key={id} href={`#${id}`} onClick={() => setMenuOpen(false)}>{label}<ArrowRight /></a>)}<a className="mobile-nav-cta" href="#contact" onClick={() => setMenuOpen(false)}>Book a Free Call <ArrowRight /></a></nav>}
      </header>

      <section className="hero-section">
        <div className="hero-grid" />
        <div className="hero-glow" />
        <div className="container hero-content">
          <Reveal className="hero-copy">
            <p className="hero-kicker"><span className="status-dot" /> AI-powered web agency</p>
            <h1>Build digital <span className="lime-text">experiences</span> that move business forward.</h1>
            <p className="hero-description">We design premium websites, AI automation systems, and digital products that make ambitious companies impossible to ignore.</p>
            <div className="hero-actions"><ButtonLink href="#contact">Get a free consultation</ButtonLink><ButtonLink href="#portfolio" secondary>View our work</ButtonLink></div>
            <div className="hero-note"><span className="avatar-stack"><i>JD</i><i>MC</i><i>AS</i></span><span>Trusted by teams building what&apos;s next</span></div>
          </Reveal>
          <Reveal className="hero-visual">
            <div className="orbit orbit-one" /><div className="orbit orbit-two" />
            <div className="laptop-wrap"><div className="laptop-screen"><div className="screen-top"><span className="screen-logo">NORTHSTAR</span><span className="screen-menu">Overview&nbsp;&nbsp; Insights&nbsp;&nbsp; Reports</span><span className="screen-avatar">JD</span></div><div className="screen-body"><div><p className="screen-label">Portfolio value</p><strong>$2,480,920</strong><p className="screen-positive">↗ 18.4% this month</p></div><div className="chart"><span /><span /><span /><span /><span /><span /><span /><span /></div><div className="screen-lower"><div><small>Performance</small><div className="mini-line" /></div><div><small>Allocation</small><div className="mini-bars"><i /><i /><i /><i /></div></div></div></div></div><div className="laptop-base" /></div>
            <div className="float-card float-seo"><span className="float-icon"><Zap /></span><div><small>Performance</small><strong>99.8 score</strong></div></div>
            <div className="float-card float-ai"><span className="float-icon"><Sparkles /></span><div><small>Automation</small><strong>AI enabled</strong></div></div>
            <div className="float-pill"><span className="pulse" /> Built for growth</div>
          </Reveal>
        </div>
        <div className="hero-bottom container"><span>Scroll to explore</span><ArrowDownRight /></div>
      </section>

      <section className="trust-bar"><div className="container trust-grid">{[['100+', 'Projects delivered'], ['50+', 'Happy clients'], ['5+', 'Years experience'], ['99%', 'Client satisfaction']].map(([number, label]) => <div key={label} className="trust-stat"><strong>{number}</strong><span>{label}</span></div>)}</div></section>

      <section id="about" className="light-section why-section"><div className="container"><Reveal><SectionHeading eyebrow="Why Kinetic" title="Good design is a growth advantage." copy="We bring strategy, craft, and technology into one focused team. The result is digital work that looks distinctive and works hard." /></Reveal><div className="why-grid">{([['01', Sparkles, 'AI integrated development', 'We build intelligent features into the experience from day one.'], ['02', Zap, 'Performance obsessed', 'Fast, accessible, and resilient is the baseline, not the finish line.'], ['03', ShieldCheck, 'Built to scale', 'A clear foundation keeps your product ready for the next chapter.']] as [string, React.ComponentType, string, string][]).map(([number, Icon, title, text]) => <Reveal key={String(title)} className="why-card"><span className="card-number">{number}</span><div className="icon-circle"><Icon /></div><h3>{String(title)}</h3><p>{String(text)}</p><ArrowUpRightIcon className="card-arrow" /></Reveal>)}</div></div></section>

      <section id="services" className="dark-section services-section"><div className="container"><Reveal><SectionHeading light eyebrow="What we do" title="A sharper digital edge." copy="From first sketch to final launch, we make the complicated feel clear and the ordinary feel exceptional." /></Reveal><div className="services-grid">{services.map(({ icon: Icon, title, text }, index) => <Reveal key={title} className="service-card"><span className="service-index">0{index + 1}</span><Icon className="service-icon" /><h3>{title}</h3><p>{text}</p><a href="#contact">Learn more <ArrowUpRightIcon /></a></Reveal>)}</div></div></section>

      <section id="portfolio" className="light-section portfolio-section"><div className="container"><Reveal><div className="heading-row"><SectionHeading eyebrow="Selected work" title="Work that earns attention." copy="A few recent launches for teams with something important to say." /><a href="#contact" className="text-link">View all projects <ArrowRight /></a></div></Reveal><div className="portfolio-grid">{projects.map((project) => <Reveal key={project.title} className="project-card"><div className="project-image-wrap"><img src={project.image} alt={`${project.title} project preview`} loading="lazy" /><span className="project-tag">{project.category}</span><span className="project-view"><ArrowUpRightIcon /></span></div><div className="project-content"><h3>{project.title}</h3><p>{project.text}</p><div><a href="#contact">Live preview <ArrowRight /></a><a href="#contact">Get something similar <ArrowRight /></a></div></div></Reveal>)}</div></div></section>

      <section id="process" className="light-section process-section"><div className="container process-layout"><Reveal><SectionHeading eyebrow="How we work" title="A process built for momentum." copy="No black boxes. No endless handoffs. Just a clear path from the first conversation to a launch you can be proud of." /></Reveal><Reveal className="timeline">{[['01', 'Discovery', 'We find the sharpest opportunity.'], ['02', 'Design', 'We give the idea a clear, compelling form.'], ['03', 'Development', 'We turn the system into something real.'], ['04', 'Testing', 'We pressure-test every detail.'], ['05', 'Launch', 'We ship, learn, and keep improving.']].map(([num, title, text], index) => <div className={`timeline-item ${index === 0 ? 'timeline-active' : ''}`} key={num}><span>{num}</span><div><h3>{title}</h3><p>{text}</p></div><ArrowRight /></div>)}</Reveal></div></section>

      <section id="pricing" className="dark-section pricing-section"><div className="container"><Reveal><SectionHeading light eyebrow="Simple investment" title="Choose your next move." copy="Flexible starting points for teams at different stages of the journey." /></Reveal><div className="pricing-grid">{[
        { title: 'Starter', price: '$3,500', text: 'For focused launches and sharp first impressions.', features: ['Landing page', 'Conversion copy', 'Responsive development', '2 weeks delivery'] },
        { title: 'Business', price: '$7,500', text: 'For brands ready to make a bigger digital leap.', features: ['Multi-page website', 'Strategy & UX direction', 'CMS integration', '4–6 weeks delivery'] },
        { title: 'eCommerce', price: '$12,500', text: 'For stores that need a better way to grow.', features: ['Custom storefront', 'Product experience design', 'Payments & analytics', '6–8 weeks delivery'] },
        { title: 'Enterprise', price: 'Let’s talk', text: 'For complex products and ambitious transformations.', features: ['Custom scope', 'Dedicated senior team', 'Systems & automation', 'Ongoing partnership'] },
      ].map((plan, index) => <Reveal key={plan.title} className={`price-card ${index === 1 ? 'price-card-featured' : ''}`}>{index === 1 && <span className="popular-pill">Most popular</span>}<h3>{plan.title}</h3><p>{plan.text}</p><strong>{plan.price}<small>{index < 3 ? ' / project' : ''}</small></strong><ul>{plan.features.map((feature) => <li key={feature}><Check />{feature}</li>)}</ul><ButtonLink href="#contact" secondary={index !== 1}>{index === 3 ? 'Start a conversation' : 'Get started'}</ButtonLink></Reveal>)}</div></div></section>

      <section className="stack-section"><div className="container"><p className="stack-label">A modern stack for modern work</p></div><div className="marquee"><div className="marquee-track">{[...techStack, ...techStack].map((tech, index) => <span key={`${tech}-${index}`}><i />{tech}</span>)}</div></div></section>

      <section className="light-section about-section"><div className="container about-layout"><Reveal className="about-image"><img src="https://images.unsplash.com/photo-1521737711867-e3b97375f902?auto=format&fit=crop&w=1200&q=85" alt="Kinetic team collaborating in a studio" loading="lazy" /><div className="about-badge"><strong>5+</strong><span>years making<br />digital useful</span></div></Reveal><Reveal className="about-copy"><SectionHeading eyebrow="A little about us" title="Small team. Big energy. Zero ego." copy="Kinetic is an independent digital studio for people who care deeply about the work. We stay small on purpose, so every project gets senior attention and a point of view." /><div className="value-row"><div><strong>Our mission</strong><p>Make the web more useful, human, and exciting.</p></div><div><strong>Our values</strong><p>Curiosity, clarity, and doing the right thing.</p></div></div><div className="social-row"><a href="#contact" aria-label="LinkedIn"><Link /></a><a href="#contact" aria-label="Message us"><MessageCircle /></a><a href="#contact" aria-label="View work"><MousePointer2 /></a></div></Reveal></div></section>

      <section id="testimonials" className="dark-section testimonials-section"><div className="container"><Reveal><SectionHeading light eyebrow="Kind words" title="Good work travels." /></Reveal><div className="testimonial-grid">{testimonials.map((item) => <Reveal key={item.name} className="testimonial-card"><div className="stars">{[1, 2, 3, 4, 5].map((star) => <Star key={star} fill="currentColor" />)}</div><blockquote>“{item.quote}”</blockquote><div className="testimonial-person"><span>{item.initials}</span><div><strong>{item.name}</strong><small>{item.role}</small></div></div></Reveal>)}</div></div></section>

      <section className="light-section faq-section"><div className="container faq-layout"><Reveal><SectionHeading eyebrow="Questions, answered" title="The useful stuff." copy="Still curious? Drop us a note and we&apos;ll get back to you with a straight answer." /><ButtonLink href="#contact">Ask us anything</ButtonLink></Reveal><Reveal className="faq-list">{faqs.map(([question, answer], index) => <div className={`faq-item ${activeFaq === index ? 'faq-open' : ''}`} key={question}><button onClick={() => setActiveFaq(activeFaq === index ? -1 : index)} aria-expanded={activeFaq === index}><span>{question}</span><ChevronDown /></button><div className="faq-answer"><p>{answer}</p></div></div>)}</Reveal></div></section>

      <section className="cta-section"><div className="container cta-box"><div className="cta-glow" /><Reveal><p className="eyebrow"><span />Your next chapter starts here</p><h2>Ready to build something <em>remarkable?</em></h2><p>Bring us the ambition. We&apos;ll bring the clarity, craft, and momentum.</p><ButtonLink href="#contact">Let&apos;s talk <ArrowUpRightIcon /></ButtonLink></Reveal></div></section>

      <section id="blog" className="light-section blog-section"><div className="container"><Reveal><div className="heading-row"><SectionHeading eyebrow="From the journal" title="Ideas worth sharing." /><a href="#contact" className="text-link">Read the journal <ArrowRight /></a></div></Reveal><div className="blog-grid">{[['Digital strategy', 'The quiet power of a sharper point of view', '6 min read', 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&w=900&q=80'], ['AI & automation', 'Where AI actually belongs in your customer experience', '8 min read', 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=900&q=80'], ['Design systems', 'How to make consistency feel anything but boring', '5 min read', 'https://images.unsplash.com/photo-1558655146-d09347e92766?auto=format&fit=crop&w=900&q=80']].map(([category, title, time, image]) => <Reveal className="blog-card" key={title}><img src={image} alt="" loading="lazy" /><div><span>{category}</span><h3>{title}</h3><p>{time} <ArrowRight /></p></div></Reveal>)}</div></div></section>

      <section id="contact" className="dark-section contact-section"><div className="container contact-layout"><Reveal className="contact-intro"><SectionHeading light eyebrow="Let&apos;s talk" title="Have a good one?" copy="Tell us a little about what you&apos;re building. We usually reply within one business day." /><div className="contact-details"><a href="mailto:hello@kinetic.studio"><span>Email</span>hello@kinetic.studio</a><a href="tel:+14155550184"><span>Phone</span>+1 415 555 0184</a><a href="#contact"><span>Based in</span>Brooklyn · Working everywhere</a></div></Reveal><Reveal className="contact-form-wrap">{submitted ? <div className="form-success"><span className="success-icon"><Check /></span><h3>Message received.</h3><p>Thanks for reaching out. We&apos;ll be in touch shortly.</p><button onClick={() => setSubmitted(false)}>Send another message <ArrowRight /></button></div> : <form className="contact-form" onSubmit={submit}><div className="form-row"><label>Name<input required name="name" placeholder="Your name" /></label><label>Email<input required type="email" name="email" placeholder="you@company.com" /></label></div><div className="form-row"><label>Phone<input name="phone" placeholder="Optional" /></label><label>Project type<select name="type" defaultValue=""><option value="" disabled>Select one</option><option>Website</option><option>Digital product</option><option>AI automation</option><option>Something else</option></select></label></div><label>What are you looking to build?<textarea required name="message" placeholder="A few words about the project, goals, and timing..." rows={5} /></label><button className="button-link form-submit" type="submit">Send inquiry <Send /></button><p className="form-privacy">Your information stays private. No spam, ever.</p></form>}</Reveal></div></section>

      <footer className="site-footer"><div className="container footer-top"><a href="#home" className="brand"><span className="brand-mark">K</span><span>KINETIC<span className="brand-dot">.</span></span></a><p>Digital experiences for companies<br />ready to move forward.</p><div className="footer-links"><div><strong>Explore</strong>{navItems.slice(1, 5).map(([label, id]) => <a href={`#${id}`} key={id}>{label}</a>)}</div><div><strong>Connect</strong><a href="mailto:hello@kinetic.studio">Email us</a><a href="#contact">LinkedIn</a><a href="#contact">Instagram</a></div></div></div><div className="container footer-bottom"><span>© 2026 Kinetic Studio. All rights reserved.</span><span>Built with intention <span className="brand-dot">•</span></span></div></footer>
    </main>
  )
}

function ArrowUpRightIcon({ className = '' }: { className?: string }) { return <ArrowUpRight className={className} aria-hidden="true" /> }
